# C-cube Modified

A Pen created on CodePen.io. Original URL: [https://codepen.io/LAKSHMAN-VVS/pen/RwzQmxo](https://codepen.io/LAKSHMAN-VVS/pen/RwzQmxo).

